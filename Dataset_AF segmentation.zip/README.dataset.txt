# Peanuts AF segmentation > 2024-11-20 8:07pm
https://universe.roboflow.com/fafu-jaxfw/peanuts-af-segmentation

Provided by a Roboflow user
License: CC BY 4.0

